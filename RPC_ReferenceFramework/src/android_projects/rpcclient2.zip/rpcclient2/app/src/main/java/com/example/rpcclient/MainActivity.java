/*
 * Copyright (c) 2026 Prajnaana Technologies
 * SPDX-License-Identifier: MIT
 *
 * Part of the Multi-Core RPC Framework.
 * See the LICENSE file in the project root for the full license text.
 *
 * Original Author: Mamatha BV
 */
package com.example.rpcclient;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.aidlserver.IRpc;
import com.example.aidlserver.RpcData;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    IRpc iRpc;
    int ServiceFlag = 0;
    int selectedFn = 0;                 // spinner position of the function to call
    EditText editArg1, editArg2, editArgText;   // per-function argument inputs
    TextView txt;                               // result label
    public final String TAG = "MainActivityRPC";
    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            iRpc = IRpc.Stub.asInterface((IBinder) iBinder);
            ServiceFlag = 1;
            Log.d(TAG, "RPC service connected. Enter server IP and tap Connect.");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Log.d(TAG, "RPC service disconnected");
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) throws RuntimeException {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent("rpcserverservice");
        intent.setPackage("com.example.aidlserver");
        Log.d(TAG, "Intent for aidl service is created");
        bindService(intent, mServiceConnection, BIND_AUTO_CREATE);

        txt = findViewById(R.id.textView);

        // Show THIS device's LAN IP. When Android is the RPC server, this is the
        // address the other cores must be pointed at:  ./core2 -s <this ip>
        TextView tvMyIp = findViewById(R.id.tvMyIp);
        String myIp = getLocalIpAddress();
        tvMyIp.setText("This device IP (use as server IP): " + myIp);
        Log.d(TAG, "This device IP = " + myIp);

        // Connect flow. Two modes:
        //  - CLIENT (default): type the server's IP, tap Connect -> socketconnect(ip).
        //  - SERVER: tick "Server mode" -> startServer() makes THIS device the hub
        //    (CORE1); no IP needed. Hand the IP shown above to core2/core3 as -s <ip>.
        // The binder call is run on a background thread: startServer() blocks in the
        // native layer until a client connects (or times out), which would ANR the
        // UI thread.
        final EditText editServerIp = findViewById(R.id.editServerIp);
        final CheckBox cbServerMode = findViewById(R.id.cbServerMode);
        Button btnConnect = findViewById(R.id.btnConnect);
        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (iRpc == null) {
                    Toast.makeText(MainActivity.this, "Service not bound yet", Toast.LENGTH_SHORT).show();
                    return;
                }
                final boolean serverMode = cbServerMode.isChecked();
                final String ip = editServerIp.getText().toString().trim();
                if (!serverMode && ip.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter the server IP (or tick Server mode)",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(MainActivity.this,
                        serverMode ? "Starting as server/hub..." : "Connecting to " + ip,
                        Toast.LENGTH_SHORT).show();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            final int rc = serverMode ? iRpc.startServer() : iRpc.socketconnect(ip);
                            Log.d(TAG, (serverMode ? "startServer" : "socketconnect(" + ip + ")")
                                    + " returned " + rc);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this,
                                            (serverMode ? "Server started (rc=" : "Connect result (rc=")
                                                    + rc + ")", Toast.LENGTH_SHORT).show();
                                }
                            });
                        } catch (Exception e) {
                            Log.e(TAG, "connect/startServer failed", e);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this, "Failed: " + e.getMessage(),
                                            Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                    }
                }).start();
            }
        });

        Spinner dropdown = (Spinner) findViewById(R.id.spinner1);
        List<String> list = new ArrayList<>();
        list.add("Select function");
        list.add("Add");
        list.add("Compute_Sqr");
        list.add("Core1Version");
        list.add("Core2Version");
        list.add("Core3Version");
        list.add("PrintHello");
        list.add("Compute_mod");
        list.add("ArrayCore3");
        list.add("PrintPoint");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                com.google.android.material.R.layout.support_simple_spinner_dropdown_item,list);

        adapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        dropdown.setAdapter(adapter);

        // Find the argument inputs first so the spinner listener can show/hide them.
        editArg1    = findViewById(R.id.editArg1);
        editArg2    = findViewById(R.id.editArg2);
        editArgText = findViewById(R.id.editArgText);

        // The spinner SELECTS the function and reveals only the fields it needs;
        // nothing is called until the user taps "Call function".
        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedFn = position;
                updateArgVisibility(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        // Call button: read the values the user typed, run the RPC on a background
        // thread (binder calls can block), and post the result back to the UI.
        Button btnCall = findViewById(R.id.btnCall);
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (iRpc == null) {
                    Toast.makeText(MainActivity.this, "Service not bound yet", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (selectedFn == 0) {
                    Toast.makeText(MainActivity.this, "Pick a function first", Toast.LENGTH_SHORT).show();
                    return;
                }
                final int    fn    = selectedFn;
                final String a1    = editArg1.getText().toString().trim();
                final String a2    = editArg2.getText().toString().trim();
                final String atext = editArgText.getText().toString();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String result;
                        try {
                            result = callFn(fn, a1, a2, atext);
                        } catch (Exception e) {
                            Log.e(TAG, "callFn failed", e);
                            result = "Error: " + e.getMessage();
                        }
                        final String out = result;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() { txt.setText(out); }
                        });
                    }
                }).start();
            }
        });
    }

    /**
     * Show only the argument fields the selected function needs, with a hint that
     * names each argument. Called from the spinner's onItemSelected.
     *   int fields: editArg1 / editArg2   text field: editArgText
     */
    private void updateArgVisibility(int fn) {
        boolean showA1 = false, showA2 = false, showTxt = false;
        String h1 = "arg 1 (int)", h2 = "arg 2 (int)", ht = "text";
        switch (fn) {
            case 1: showA1 = showA2 = true; h1 = "a (int)"; h2 = "b (int)"; break;   // Add
            case 2: showA1 = true;          h1 = "x (int)";                 break;   // Compute_Sqr
            case 6: showTxt = true;         ht = "text to print";          break;    // PrintHello
            case 7: showA1 = showA2 = true; h1 = "x (int)"; h2 = "y (int)"; break;   // Compute_mod
            case 8: showTxt = true;         ht = "ints, comma or space: 1,2,3 or 1 2 3"; break;  // ArrayCore3
            case 9: showA1 = showA2 = true; h1 = "x (int)"; h2 = "y (int)"; break;   // PrintPoint
            default: break;   // 0 = none, 3/4/5 = version calls take no args
        }
        // Clear any leftover input and the old result when the function changes.
        editArg1.setText("");
        editArg2.setText("");
        editArgText.setText("");
        if (txt != null) txt.setText("Result");
        editArg1.setHint(h1);
        editArg2.setHint(h2);
        editArgText.setHint(ht);
        editArg1.setVisibility(showA1 ? View.VISIBLE : View.GONE);
        editArg2.setVisibility(showA2 ? View.VISIBLE : View.GONE);
        editArgText.setVisibility(showTxt ? View.VISIBLE : View.GONE);
    }

    /** Which core (1..3) implements the given spinner function; 0 = local/no core. */
    private static int coreForFn(int fn) {
        switch (fn) {
            case 1: return 0;                 // Add — local, non-RPC
            case 2: case 4: return 2;         // Compute_Sqr, Core2Version -> CORE2
            case 3: case 7: case 9: return 1; // Core1Version, Compute_mod, PrintPoint -> CORE1
            case 5: case 6: case 8: return 3; // Core3Version, PrintHello, ArrayCore3 -> CORE3
            default: return 0;
        }
    }

    /** Parse an int from user text, or return def if empty/invalid. */
    private static int parseIntOr(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    /**
     * Invoke the selected RPC with USER-SUPPLIED arguments (no hardcoded values).
     * Returns a human-readable result string. Runs on a background thread.
     * arg1/arg2 are the two integer fields; text is the text/CSV field.
     */
    private String callFn(int fn, String arg1, String arg2, String text) throws RemoteException {
        // Guard: if the function's owning core is not in the network, report it
        // instead of firing the call (a call to a disconnected core would block
        // the INOUT/OUT reply forever). CORE1 functions run locally (always ok).
        int needCore = coreForFn(fn);
        if (needCore >= 1 && iRpc.isCorePresent(needCore) == 0) {
            return "CORE" + needCore + " is NOT connected.\n"
                 + "Connect CORE" + needCore + " to the hub, then try again.";
        }
        switch (fn) {
            // Every case returns ONLY the value that came back from the core.
            case 1: {   // Add(a, b) -> a+b
                int a = parseIntOr(arg1, 0), b = parseIntOr(arg2, 0);
                RpcData sum = new RpcData();
                iRpc.add(a, b, sum);
                return String.valueOf(sum.getX());
            }
            case 2: {   // Compute_Sqr(x) -> x*x
                int x = parseIntOr(arg1, 0);
                RpcData psqr = new RpcData();
                iRpc.rpc_compute_sqr(x, psqr);
                return String.valueOf(psqr.getX());
            }
            case 3: {
                RpcData r = new RpcData();
                iRpc.rpc_get_rpc_version_core1(r);
                return String.valueOf(r.getX());
            }
            case 4: {
                RpcData r = new RpcData();
                iRpc.rpc_get_rpc_version_core2(r);
                return String.valueOf(r.getX());
            }
            case 5: {
                RpcData r = new RpcData();
                iRpc.rpc_get_rpc_version_core3(r);
                return String.valueOf(r.getX());
            }
            case 6: {   // PrintHello(text) — CORE3 returns "Hello <text>"
                String s = text.isEmpty() ? arg1 : text;
                if (s.isEmpty()) return "Enter text in the text field for PrintHello";
                int iSize = "Hello ".length() + s.getBytes().length + 1;
                RpcData strData = new RpcData();
                strData.setS(s);
                iRpc.rpc_print_hello(iSize, strData);
                return strData.getS();                       // just the returned string
            }
            case 7: {   // Compute_mod(x, y) -> x % y
                int x = parseIntOr(arg1, 0), y = parseIntOr(arg2, 0);
                if (y == 0) return "mod: arg 2 (y) must be non-zero";
                RpcData rpcmod = new RpcData();
                iRpc.rpc_compute_mod(x, y, rpcmod);
                return String.valueOf(rpcmod.getX());
            }
            case 8: {   // ArrayCore3(CSV ints) — CORE3 returns the array
                String csv = text.trim();
                if (csv.isEmpty()) return "Enter ints separated by commas or spaces (e.g. 1,2,3 or 1 2 3)";
                // Accept commas AND/OR spaces as separators: "1,2,3", "1 2 3", "1, 2  3".
                String[] parts = csv.split("[,\\s]+");
                int[] arr = new int[parts.length];
                for (int i = 0; i < parts.length; i++) arr[i] = parseIntOr(parts[i], 0);
                RpcData rpcArr = new RpcData();
                rpcArr.setRpcarray(arr);
                iRpc.rpc_array_core3(arr.length, rpcArr);
                return java.util.Arrays.toString(rpcArr.getRpcarray());   // just the returned array
            }
            case 9: {   // PrintPoint(x, y) -> (x+1, y+1)
                int x = parseIntOr(arg1, 0), y = parseIntOr(arg2, 0);
                RpcData rpcin = new RpcData(), rpcout = new RpcData();
                rpcin.setPointStruct(new RpcData.rpcpoint(x, y));
                iRpc.rpc_print_point_core1(rpcin, rpcout);
                return rpcout.getPointStruct().x + ", " + rpcout.getPointStruct().y;
            }
            default:
                return "Pick a function";
        }
    }

    /**
     * This device's first non-loopback IPv4 address (typically the Wi-Fi/wlan0
     * address). Needs no permission - java.net.NetworkInterface enumeration is
     * open. Returned to display as the server IP when Android is the RPC server.
     */
    private String getLocalIpAddress() {
        // 1) Enumerate interfaces, preferring wlan/eth. Each interface is guarded
        //    on its own: some virtual interfaces (ipsec, dummy, rmnet) throw on
        //    isUp()/getInetAddresses() on Android 11+, and one bad one must NOT
        //    abort the whole scan (the previous version returned "unavailable"
        //    whenever the FIRST interface threw).
        try {
            java.util.Enumeration<java.net.NetworkInterface> en =
                    java.net.NetworkInterface.getNetworkInterfaces();
            // getNetworkInterfaces() returns NULL on some emulator images (the old
            // code NPE'd on Collections.list(null) -> "unavailable"). Guard it.
            java.util.List<java.net.NetworkInterface> ifs =
                    (en == null) ? new java.util.ArrayList<java.net.NetworkInterface>()
                                 : java.util.Collections.list(en);
            for (String pref : new String[]{"wlan", "eth", "en", ""}) {
                for (java.net.NetworkInterface intf : ifs) {
                    try {
                        if (intf.isLoopback()) continue;
                        String nm = (intf.getName() == null) ? "" : intf.getName().toLowerCase();
                        if (!pref.isEmpty() && !nm.startsWith(pref)) continue;
                        for (java.net.InetAddress addr :
                                java.util.Collections.list(intf.getInetAddresses())) {
                            if (!addr.isLoopbackAddress() && addr instanceof java.net.Inet4Address) {
                                return addr.getHostAddress();
                            }
                        }
                    } catch (Exception perIf) {
                        /* skip this interface, keep scanning */
                    }
                }
            }
        } catch (Exception ex) {
            Log.e(TAG, "getLocalIpAddress: interface scan failed", ex);
        }
        // 2) WifiManager fallback - reliable on the emulator's virtual Wi-Fi,
        //    where getNetworkInterfaces() returns null. Needs ACCESS_WIFI_STATE.
        try {
            android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager)
                    getApplicationContext().getSystemService(android.content.Context.WIFI_SERVICE);
            if (wm != null) {
                int ip = wm.getConnectionInfo().getIpAddress();
                if (ip != 0) {
                    return (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "."
                            + ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
                }
            }
        } catch (Exception ex) {
            Log.e(TAG, "getLocalIpAddress: WifiManager fallback failed", ex);
        }
        // 3) Fallback: connect a UDP socket to a public address (no packets are
        //    sent) and read back the source address the kernel picked. Works on
        //    all API levels whenever any network route exists.
        try {
            java.net.DatagramSocket s = new java.net.DatagramSocket();
            s.connect(java.net.InetAddress.getByName("8.8.8.8"), 53);
            java.net.InetAddress local = s.getLocalAddress();
            s.close();
            if (local != null && !local.isAnyLocalAddress()) {
                return local.getHostAddress();
            }
        } catch (Exception ex) {
            Log.e(TAG, "getLocalIpAddress: UDP fallback failed", ex);
        }
        return "unavailable (not on a network?)";
    }
}