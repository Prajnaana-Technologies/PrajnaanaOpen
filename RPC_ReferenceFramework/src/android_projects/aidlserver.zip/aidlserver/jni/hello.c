/*
 * Copyright (c) 2026 Prajnaana Technologies
 * SPDX-License-Identifier: MIT
 *
 * Part of the Multi-Core RPC Framework.
 * See the LICENSE file in the project root for the full license text.
 *
 * Original Author: Mamatha BV
 */
#include"jni.h"
#include<stdlib.h>
#include <android/log.h>
#include <rpc_fn.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>

extern void rpc_set_server_ip(const char *ip);   /* defined in osal.c */
extern void rpc_set_server_core(int core_num);    /* defined in osal.c */
extern int  rpc_is_core_present(int c);           /* osal.c: 1 if core c (0-based) is usable */

/* Is CORE<coreNum> (1..3) currently reachable? 1 = yes (self or connected), 0 = no.
 * The UI calls this before invoking a function so it can show "core not connected"
 * instead of blocking on a core that isn't in the network. */
jint Java_com_example_aidlserver_rpcserverservice_corePresent
(JNIEnv * env , jobject obj , jint coreNum)
{
     if (coreNum < 1 || coreNum > 3) return 0;
     return rpc_is_core_present((int)coreNum - 1) ? 1 : 0;   /* JNI 1-based -> 0-based enum */
}

/* Set the server IP before startrpc(). For a CLIENT this is the IP of whichever
 * core is the server/hub (e.g. the Linux CORE2 at "192.168.31.38"). Ignored when
 * THIS device is the server. */
void Java_com_example_aidlserver_rpcserverservice_setServerIp
(JNIEnv * env , jobject obj , jstring jip)
{
     const char *ip = (*env)->GetStringUTFChars(env, jip, NULL);
     rpc_set_server_ip(ip);
     (*env)->ReleaseStringUTFChars(env, jip, ip);
}

/* Choose which core is the server/hub (1..3). Call BEFORE startrpc().
 *   setServerCore(2)  -> CORE2 is server, Android is a client (default topology)
 *   setServerCore(1)  -> Android (CORE1) IS the server; core2/core3 connect in. */
void Java_com_example_aidlserver_rpcserverservice_setServerCore
(JNIEnv * env , jobject obj , jint core_num)
{
     rpc_set_server_core((int)core_num);
}

/* Return this device's first non-loopback IPv4 address as a String (or "" if
 * none). Useful to display when Android is the server, so you can point the
 * desktop clients at it:  ./core2 -s <this_ip>. No extra permission needed. */
jstring Java_com_example_aidlserver_rpcserverservice_getLocalIp
(JNIEnv * env , jobject obj )
{
     /* Portable across all API levels (getifaddrs needs API 24): open a UDP
      * socket, "connect" it to a public address (no packets are sent - connect on
      * a datagram socket only fixes the peer and makes the kernel pick the source
      * address per the routing table), then read that source address back with
      * getsockname(). That source IP is this device's LAN address. */
     char ipbuf[INET_ADDRSTRLEN] = "";
     int  s = socket(AF_INET, SOCK_DGRAM, 0);
     if (s >= 0)
     {
          struct sockaddr_in peer;
          memset(&peer, 0, sizeof(peer));
          peer.sin_family = AF_INET;
          peer.sin_port   = htons(53);                 /* arbitrary */
          peer.sin_addr.s_addr = inet_addr("8.8.8.8"); /* just to select a route */

          if (connect(s, (struct sockaddr *)&peer, sizeof(peer)) == 0)
          {
               struct sockaddr_in local;
               socklen_t len = sizeof(local);
               if (getsockname(s, (struct sockaddr *)&local, &len) == 0)
               {
                    inet_ntop(AF_INET, &local.sin_addr, ipbuf, sizeof(ipbuf));
               }
          }
          close(s);
     }
     return (*env)->NewStringUTF(env, ipbuf);
}

jint Java_com_example_aidlserver_rpcserverservice_startrpc
(JNIEnv * env , jobject obj)
{
     start_rpc();
     return 0;
}
jstring Java_com_example_aidlserver_rpcserverservice_rpcMain
(JNIEnv * env , jobject obj )
{
    rpc_main();
    return ( * env ) -> NewStringUTF(env, "AIDL server" ) ;
}

jint Java_com_example_aidlserver_rpcserverservice_core2Version
(JNIEnv * env , jobject obj , jobject rpc )
{
    jclass thisClass = (*env)->GetObjectClass(env, rpc);
    jfieldID fidNumber = (*env)->GetFieldID(env, thisClass, "x", "I");
    if (NULL == fidNumber)
    {
        return 0;
    }
    jint number;// = (*env)->GetIntField(env, rpc, fidNumber);
    int res = fn_get_rpc_version_core2(&number);
    (*env)->SetIntField(env, rpc, fidNumber, number);
    printf("core2 version = %d",number);
    return (res);
 }

jint Java_com_example_aidlserver_rpcserverservice_core1Version
(JNIEnv * env , jobject obj , jobject rpc )
{
    jclass thisClass = (*env)->GetObjectClass(env, rpc);
    jfieldID fidNumber = (*env)->GetFieldID(env, thisClass, "x", "I");
    if (NULL == fidNumber)
    {
        return 0;
    }
    jint number;// = (*env)->GetIntField(env, rpc, fidNumber);
    int res = fn_get_rpc_version_core1(&number);
    (*env)->SetIntField(env, rpc, fidNumber, number);
    printf("core1 version = %d",number);
    return (res);
 }

 jint Java_com_example_aidlserver_rpcserverservice_core3Version
 (JNIEnv * env , jobject obj , jobject rpc )
 {
    jclass thisClass = (*env)->GetObjectClass(env, rpc);
    jfieldID fidNumber = (*env)->GetFieldID(env, thisClass, "x", "I");
    if (NULL == fidNumber)
    {
        return 0;
    }
    jint number;// = (*env)->GetIntField(env, rpc, fidNumber);
    int res = fn_get_rpc_version_core3(&number);
    (*env)->SetIntField(env, rpc, fidNumber, number);
    printf("core3 version = %d",number);
    return (res);
  }

  jint Java_com_example_aidlserver_rpcserverservice_computesqr
  (JNIEnv * env , jobject obj , int x1, jobject sqr )
  {
     jclass thisClass = (*env)->GetObjectClass(env, sqr);
     jfieldID fidNumber = (*env)->GetFieldID(env, thisClass, "x", "I");
     if (NULL == fidNumber)
     {
          return 0;
     }
     jint number; /*= (*env)->GetIntField(env, sqr, fidNumber);*/
     int res = fn_compute_sqr(x1,&number);
     (*env)->SetIntField(env, sqr, fidNumber, number);
     printf("sqr = %d",number);
     return (res);
   }

jint Java_com_example_aidlserver_rpcserverservice_computemod
(JNIEnv * env , jobject obj , int x1, int y, jobject sqr )
{
   jclass thisClass = (*env)->GetObjectClass(env, sqr);
   jfieldID fidNumber = (*env)->GetFieldID(env, thisClass, "x", "I");
   if (NULL == fidNumber)
   {
        return 0;
   }
   jint number; /*= (*env)->GetIntField(env, sqr, fidNumber);*/
   int res = fn_compute_mod(x1,y,&number);
   (*env)->SetIntField(env, sqr, fidNumber, number);
   printf("mod = %d",number);
   return (res);
 }

 /* print_str is INOUT: read the caller's string out of RpcData.s, hand CORE3 a
  * buffer of iSize bytes, CORE3 prefixes "Hello " + prints + echoes it back, then
  * write the echoed result into RpcData.s so the AIDL 'inout' returns it. */
 jint Java_com_example_aidlserver_rpcserverservice_printhello
 (JNIEnv * env , jobject obj , int iSize, jobject strData )
 {
    jclass    cls   = (*env)->GetObjectClass(env, strData);
    jfieldID  fid_s = (*env)->GetFieldID(env, cls, "s", "Ljava/lang/String;");
    jstring   js    = (jstring)(*env)->GetObjectField(env, strData, fid_s);

    const char *in = (js != NULL) ? (*env)->GetStringUTFChars(env, js, NULL) : "";
    if (iSize < 1) { iSize = 1; }

    /* Buffer of iSize bytes, zero-filled so the string is always terminated. */
    char *buf = (char *)calloc((size_t)iSize, 1);
    if (buf == NULL)
    {
        if (js != NULL) (*env)->ReleaseStringUTFChars(env, js, in);
        return RPCERR_MALLOC_FAILED;
    }
    strncpy(buf, in, (size_t)iSize - 1);        /* input at the front */
    if (js != NULL) (*env)->ReleaseStringUTFChars(env, js, in);

    printf("printhello: sending \"%s\" (buf=%d) to CORE3\n", buf, iSize);
    int res = fn_print_hello(iSize, buf);        /* CORE3 -> "Hello <input>", echoed */
    printf("printhello: CORE3 echoed \"%s\"\n", buf);

    /* Write the echoed result back into RpcData.s for the 'inout' return. */
    jstring out = (*env)->NewStringUTF(env, buf);
    (*env)->SetObjectField(env, strData, fid_s, out);
    free(buf);
    return (res);
  }

  jint Java_com_example_aidlserver_rpcserverservice_printpoint
  (JNIEnv * env , jobject obj , jobject inRpcData, jobject outRpcData  )
  {
      jclass cls = (*env) -> GetObjectClass( env, inRpcData ); //to get the class
      jfieldID fid_Point     = (*env) -> GetFieldID( env, cls, "PointStruct", "Lcom/example/aidlserver/RpcData$rpcpoint;");
       if (NULL == fid_Point)
         {
            printf("Field ID is null");
              return 0;
         }
      jobject Inpoint_obj      = (*env) -> GetObjectField( env, inRpcData, fid_Point );
      jclass clsClassB   = (*env) -> GetObjectClass( env, Inpoint_obj );
      jfieldID fid_x1    = (*env) -> GetFieldID( env, clsClassB, "x", "I" );
      jfieldID fid_y1    = (*env) -> GetFieldID( env, clsClassB, "y", "I" );
      int valx          = (*env) -> GetIntField( env, Inpoint_obj, fid_x1 );
      int valy          = (*env) -> GetIntField( env, Inpoint_obj, fid_y1 );

      sPoint pointOut, pointIn;
      pointIn.x = valx;
      pointIn.y = valy;
      int res = fn_print_point_core1(pointIn, &pointOut);

       jobject Outpoint_obj      = (*env) -> GetObjectField( env, outRpcData, fid_Point );
       jclass clsClassBout   = (*env) -> GetObjectClass( env, Outpoint_obj );
       jfieldID fid_x1out    = (*env) -> GetFieldID( env, clsClassBout, "x", "I" );
       jfieldID fid_y1out    = (*env) -> GetFieldID( env, clsClassBout, "y", "I" );

       (*env)->SetIntField(env, Outpoint_obj, fid_x1out, pointOut.x);
       (*env)->SetIntField(env, Outpoint_obj, fid_y1out, pointOut.y);

      return res;

   }


jint Java_com_example_aidlserver_rpcserverservice_ArrayCORE3
(JNIEnv * env , jobject obj , int arraysize, jobject rpcarrData )
{
   /* Pull the int[] out of the RpcData object via its getRpcarray() getter. */
   jclass    cls = (*env)->GetObjectClass(env, rpcarrData);
   jmethodID mid = (*env)->GetMethodID(env, cls, "getRpcarray", "()[I");
   jintArray arr = (jintArray)(*env)->CallObjectMethod(env, rpcarrData, mid);
   if (arr == NULL)
   {
        printf("ArrayCORE3: rpcarray is null\n");
        return RPCERR_INVALID_ARG;
   }

   /* Use the ACTUAL array length (not the separately-passed size, which could
    * disagree). This is what makes any array length work, not just 4. */
   jsize  arrSize = (*env)->GetArrayLength(env, arr);
   jint  *arrC    = (*env)->GetIntArrayElements(env, arr, NULL);
   if (arrC == NULL)
   {
        printf("ArrayCORE3: GetIntArrayElements returned null\n");
        return RPCERR_INVALID_ARG;
   }

   printf("ArrayCORE3: sending %d element(s) to CORE3 for print-back:\n", (int)arrSize);
   for (int i = 0; i < arrSize; i++)
   {
        printf("  in  [%d] = %d\n", i, arrC[i]);
   }

   /* fn_array_core3 is now INOUT (like fn_print_point_core1): the array is sent to
    * CORE3, printed there, and echoed back into the SAME buffer. This call blocks
    * until CORE3's response arrives, after which arrC holds the echoed array. */
   int res = fn_array_core3((int)arrSize, arrC);

   /* PRINT THE ECHOED ARRAY on the Android side (logcat, tag RPC_MAIN). */
   printf("ArrayCORE3: CORE3 echoed back (res=%d):\n", res);
   for (int i = 0; i < arrSize; i++)
   {
        printf("  out [%d] = %d\n", i, arrC[i]);
   }

   /* mode 0 = copy arrC back into the Java int[] + free. This is what carries the
    * echoed array into RpcData so the AIDL 'inout' returns it to the caller. */
   (*env)->ReleaseIntArrayElements(env, arr, arrC, 0);
   return (res);
}





