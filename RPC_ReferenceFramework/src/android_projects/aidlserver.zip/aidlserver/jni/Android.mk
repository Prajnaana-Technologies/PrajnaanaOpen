LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := rpctest
LOCAL_SRC_FILES := hello.c main_file.c  osal.c rpc_core1.c rpc_core1_server.c rpc_core1_client.c rpc_marshall.c
LOCAL_INC_FILES := rpc_fn.h osal.h rpc_fncode.h rpc_marshall.h
LOCAL_LDLIBS := -llog
include $(BUILD_SHARED_LIBRARY)
