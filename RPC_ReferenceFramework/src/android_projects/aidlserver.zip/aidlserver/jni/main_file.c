/*
 * Copyright (c) 2026 Prajnaana Technologies
 * SPDX-License-Identifier: MIT
 *
 * Part of the Multi-Core RPC Framework.
 * See the LICENSE file in the project root for the full license text.
 *
 * Original Author: Mamatha BV
 */
/*
 * main_file.c  (ANDROID / JNI build of CORE1)
 *
 *  Created on: May 8, 2023
 *      Author: mc
 *
 * This is the Android-side entry used by the JNI layer (hello.c). It is NOT the
 * desktop interactive menu - it only provides:
 *   - rpc_on_membership_change() : required hook pulled in by osal.c/rpc_marshall.c
 *   - start_rpc()                : bring up the RPC threads, wait briefly for a link
 *   - rpc_main()                 : optional self-test that exercises every function
 *
 * Role (client vs server) and the server IP are chosen by the app through the
 * JNI setters setServerCore()/setServerIp() BEFORE start_rpc() is called.
 */
#define RPCHDR_START_SIGN           (0x50A0050Au)
#define RPCHDR_END_SIGN             (0xAF5FFAF5u)

#include <stdio.h>
#include <unistd.h>

#include "rpc_fn.h"

#include "rpc_fncode.h"
#include "osal.h"

extern void rpc_init(void);
extern StructSocketInfo sSocketInfo[RPCCORE_COUNT];
extern int connect_count;                 /* number of live links (osal.c) */
extern volatile int g_rpc_link_failed;    /* set when a CLIENT cannot reach its server */

/* How long start_rpc()/rpc_main() wait for the first link before returning. The
 * receive threads keep running in the background regardless. */
#define RPC_LINK_WAIT_SECS   15

/* ------------------------------------------------------------------------
 * Membership hook. On the desktop this redraws the interactive menu; on Android
 * there is no menu, so we just log who is currently reachable. This MUST exist -
 * osal.c (rpc_apply_membership / socket_*_init) and rpc_marshall.c reference it.
 * ---------------------------------------------------------------------- */
void rpc_on_membership_change(void)
{
	enumFnCore c;
	printf("[membership] core %d sees: ", get_this_core());
	for (c = RPCCORE_CORE1; c < RPCCORE_COUNT; c++)
	{
		printf("core%d=%s ", c, rpc_is_core_present(c) ? "up" : "down");
	}
	printf("\n");
}

/* Wait (bounded) for the network to come up: a CLIENT needs one link to the
 * server; a SERVER needs at least one client. Returns 1 if a link is up, 0 if it
 * gave up / failed. Never blocks forever (that would wedge the binder thread). */
static int rpc_wait_for_link(void)
{
	int waited = 0;
	while (waited < RPC_LINK_WAIT_SECS)
	{
		if (connect_count >= 1)
		{
			printf("rpc_wait_for_link(): link up (connect_count=%d)\n", connect_count);
			return 1;
		}
		if (g_rpc_link_failed)
		{
			printf("rpc_wait_for_link(): link FAILED (could not reach server)\n");
			return 0;
		}
		sleep(1);
		waited++;
	}
	printf("rpc_wait_for_link(): timed out after %ds (connect_count=%d)\n",
	       RPC_LINK_WAIT_SECS, connect_count);
	return (connect_count >= 1);
}

/* Called from JNI startrpc(). Spawns the RPC receive thread(s) (rpc_init returns
 * immediately; the blocking accept()/connect() happen inside those threads) and
 * waits a short while for the link so the caller gets a meaningful result. */
void start_rpc(void)
{
	rpc_init();
	(void) rpc_wait_for_link();
}

int rpc_main()
{
	enumRpcErr eRR = 2;
	int Result = 0;
	sPoint sp, sP_out;
	sp.x = 3;
	sp.y = 6;
	int arr[4] = {1, 2, 3, 4};

	rpc_init();
	if (!rpc_wait_for_link())
	{
		printf("rpc_main(): no link - aborting self-test\n");
		return RPCERR_SEND_FAILED;
	}

	eRR = RPCERR_SEND_FAILED;
	while ((eRR != RPCERR_SUCCESS) && (eRR == RPCERR_SEND_FAILED))
	{
		eRR = fn_get_rpc_version_core2(&Result);
		if (eRR != RPCERR_SUCCESS)
		{
			printf("\t\t!!!!!!!!!!ERROR CORE2 Result = %d, retrying SEND....\n", eRR);
			sleep(4);
		}
		else
		{
			printf(" \t\t **** main(): CORE2 RESULT = %d\n", Result);
		}
	}

	Result = 0;
	eRR = RPCERR_SEND_FAILED;
	while ((eRR != RPCERR_SUCCESS) && (eRR == RPCERR_SEND_FAILED))
	{
		eRR = fn_get_rpc_version_core1(&Result);
		if (eRR != RPCERR_SUCCESS)
		{
			printf("\t\t!!!!!!!!!! ERROR CORE1 Result = %d, retrying SEND ...\n", eRR);
			sleep(4);
		}
		else
		{
			printf("\t\t **** main(): CORE1 RESULT = %d\n", Result);
		}
	}

	Result = 0;
	eRR = RPCERR_SEND_FAILED;
	while ((eRR != RPCERR_SUCCESS) && (eRR == RPCERR_SEND_FAILED))
	{
		eRR = fn_print_point_core1(sp, &sP_out);
		if (eRR != RPCERR_SUCCESS)
		{
			printf("ERROR CORE1 point Result = %d, retrying SEND ...\n", eRR);
			sleep(4);
		}
		else
		{
			printf("\t\t **** main(): CORE1 Point print function, X = %d, Y = %d\n", sP_out.x, sP_out.y);
		}
	}

	Result = 0;
	eRR = RPCERR_SEND_FAILED;
	while ((eRR != RPCERR_SUCCESS) && (eRR == RPCERR_SEND_FAILED))
	{
		sPoint spoint;
		spoint.x = 9;
		spoint.y = 8;
		sPoint sOut;
		int arr_out[4];
		int i = 0;

		eRR = fn_test_all(9, 27, "TESTALL FUNCTION FROM MAIN", spoint, 4, &arr[0], &sOut, 4, &arr_out[0]);

		if (eRR != RPCERR_SUCCESS)
		{
			printf("ERROR CORE3 TESTALL = %d, retrying SEND ...\n", eRR);
			sleep(4);
		}
		else
		{
			printf("\t\t **** main(): CORE3 TEStALL function\n");
			printf("*************** structure o/p X= %d, Y = %d\n", sOut.x, sOut.y);
			printf("********** Array output = [");
			for (i = 0; i < 4; i++)
			{
				printf("%d ", arr_out[i]);
			}
			printf("]\n");
		}
	}

	Result = 0;
	eRR = RPCERR_SEND_FAILED;
	while ((eRR != RPCERR_SUCCESS) && (eRR == RPCERR_SEND_FAILED))
	{
		eRR = fn_get_rpc_version_core3(&Result);
		if (eRR != RPCERR_SUCCESS)
		{
			printf("\t\t!!!!!!!!! ERROR CORE3 Result = %d, retrying SEND...\n", eRR);
			sleep(4);
		}
		else
		{
			printf(" \t\t **** main(): CORE3 RESULT = %d\n", Result);
		}
	}

	Result = 0;
	eRR = RPCERR_SEND_FAILED;
	while ((eRR != RPCERR_SUCCESS) && (eRR == RPCERR_SEND_FAILED))
	{
		eRR = fn_array_core3(4, &arr[0]);
		if (eRR != RPCERR_SUCCESS)
		{
			printf("ERROR CORE3 Array Result = %d, retrying SEND ...\n", eRR);
			sleep(4);
		}
		else
		{
			printf("\t\t **** main(): CORE3 Array function\n");
		}
	}

	eRR = fn_print_hello(28, "HELLO , CORE3 PRINT FUNCTION ");

	return eRR;
}
