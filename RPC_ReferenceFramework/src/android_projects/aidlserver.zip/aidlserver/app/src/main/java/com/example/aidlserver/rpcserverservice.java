/*
 * Copyright (c) 2026 Prajnaana Technologies
 * SPDX-License-Identifier: MIT
 *
 * Part of the Multi-Core RPC Framework.
 * See the LICENSE file in the project root for the full license text.
 *
 * Original Author: Mamatha BV
 */
package com.example.aidlserver;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

public class rpcserverservice extends Service {
    public rpcserverservice() {
    }


    public native String rpcMain();
    public native int startrpc();
    public native void setServerIp(String ip);
    public native void setServerCore(int coreNum);   // 1..3: which core is the server/hub
    public native String getLocalIp();               // this device's LAN IPv4 (for server mode)
    public native int corePresent(int coreNum);      // 1 if CORE<coreNum> is reachable, else 0
    public native int computesqr(int x, RpcData sqr);
    public native int computemod(int x , int y , RpcData mod);
    public native int core2Version(RpcData string);
    public native int core3Version(RpcData string);
    public native int core1Version(RpcData string);
    public native int printhello (int iSize,  RpcData strData);
    public native int printpoint ( RpcData sP,  RpcData psP);
    public native int ArrayCORE3(int iSize,RpcData ai_Arr);

    static {
        System.loadLibrary("rpctest");
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return binder;
    }
    private final IRpc.Stub binder = new IRpc.Stub() {
        @Override
        public IBinder asBinder() {
            return null;
        }

        @Override
        public int socketconnect(String serverIp) throws RemoteException {
            // CORE2 (server) IP is supplied by the caller (typed into the client
            // UI). If none is given, fall back to the build variant default:
            // emulator -> 10.0.2.2, phone -> PHONE_SERVER_IP from rpc_config.properties.
            String ip = (serverIp != null && !serverIp.trim().isEmpty())
                    ? serverIp.trim() : BuildConfig.SERVER_IP;
            rpcserverservice.this.setServerCore(2);   // client: server is CORE2/CORE3, not us
            rpcserverservice.this.setServerIp(ip);
            Log.d("rpcservice:socketconnect", "Socket init as CLIENT, server IP = " + ip);
            return(startrpc());
        }

        @Override
        public int isCorePresent(int coreNum) throws RemoteException {
            return rpcserverservice.this.corePresent(coreNum);
        }

        @Override
        public int startServer() throws RemoteException {
            // Make THIS device (CORE1) the server/hub, then start. No server IP is
            // needed - a server binds all interfaces. core2/core3 connect in with
            // -s <this device's IP> (shown at the top of the client screen).
            rpcserverservice.this.setServerCore(1);
            Log.d("rpcservice:startServer", "Starting as SERVER/hub (CORE1), IP = "
                    + rpcserverservice.this.getLocalIp());
            return(startrpc());
        }

        @Override
        public int add(int a, int b , RpcData outrpc ) throws RemoteException {
            Log.d("rpcservice:Add", "NonRpc add called" );
            int d = a+b;
            outrpc.setX(d);
            Log.d("rpcservice:add", "val:"+Float.toString(outrpc.getX()));
            return 0;
        }
        @Override
        public int rpc_compute_sqr(int x, RpcData psqr) throws RemoteException {
            Log.d("rpcservice:ComputeSqr", "Compute square called" );
            int res = 0;
            res = computesqr(x,psqr);
            Log.d("rpcservice", "val:"+Float.toString(psqr.getX()) );
            return res;

        }
        @Override
        public int rpc_call() throws RemoteException {
            Log.d("rpcservice:rpcMain", String.format("RPC main function called"));
            rpcMain();
          return (1);
        }

        @Override
        public int rpc_get_rpc_version_core2(RpcData p_rpc_ver) throws RemoteException {
            Log.d("rpcservice:CORE2version", String.format("CORE2 version called"));
            int res =  core2Version(p_rpc_ver);
            Log.d("rpcservice:CORE2version", "CORE2 Version = "+String.valueOf(p_rpc_ver.getX()));
            return res;
        }
        @Override
        public int rpc_get_rpc_version_core1(RpcData p_rpc_ver) throws RemoteException {
            Log.d("rpcservice:CORE1version", String.format("CORE1 version called"));
            int res =  core1Version(p_rpc_ver);
            Log.d("rpcservice:CORE1version", "CORE1 Version = "+String.valueOf(p_rpc_ver.getX()));
            return res;
        }
        @Override
        public int rpc_get_rpc_version_core3(RpcData p_rpc_ver) throws RemoteException {
            Log.d("rpcservice:CORE3version", String.format("CORE3 version called"));
            int res = core3Version(p_rpc_ver);
            Log.d("rpcservice:CORE3version", "CORE3 Version = "+String.valueOf(p_rpc_ver.getX()));
            return res;
        }

        @Override
        public int  rpc_compute_mod (int x, int y, RpcData pmod) throws RemoteException {
            Log.d("rpcservice:Computemod", String.format("Computemod Called"));
            int res = 0;
            res = computemod(x,y,pmod);
            Log.d("rpcservice:Computemod", "val:"+Float.toString(pmod.getX()) );
            return res;
        }
        @Override
        public int  rpc_print_hello (int iSize,  RpcData strData) throws RemoteException {
            Log.d("rpcservice:Printhello", "Printhello called, in=" + strData.getS());
            int res = printhello(iSize, strData);   // CORE3 prefixes "Hello ", echoes back
            Log.d("rpcservice:Printhello", "Printhello echoed=" + strData.getS());
            return res;
        }

        @Override
        public int  rpc_print_point_core1 ( RpcData sP,  RpcData psP) throws RemoteException {
            Log.d("rpcservice:PrintPointStruct", String.format("PrintPoint Called"));
            int res = 0;
            res = printpoint(sP,psP);;
            Log.d("rpcservice:PrintPointStruct", "Point updated: x="+psP.PointStruct.x+" y="+ psP.PointStruct.y );
            return res;
        }

        @Override
        public int   rpc_array_core3 (int iSize, RpcData ai_Arr) throws RemoteException {
            int[] checkarr = ai_Arr.getRpcarray();
            // Log the ACTUAL array (any length). The old code indexed [0..3] and
            // crashed with ArrayIndexOutOfBounds for arrays shorter than 4.
            Log.d("rpcservice:ArrayCORE3", "ArrayCORE3 called, size=" + iSize
                    + " arr=" + java.util.Arrays.toString(checkarr));
            int res = ArrayCORE3(iSize, ai_Arr);
            Log.d("rpcservice:ArrayCORE3", "echoed=" + java.util.Arrays.toString(ai_Arr.getRpcarray()));
            return res;
        }




    };


}