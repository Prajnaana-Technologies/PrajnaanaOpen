/*
 * Copyright (c) 2026 Prajnaana Technologies
 * SPDX-License-Identifier: MIT
 *
 * Part of the Multi-Core RPC Framework.
 * See the LICENSE file in the project root for the full license text.
 *
 * Original Author: Mamatha BV
 */
package com.example.aidlserver;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class RpcData implements Parcelable {
    public String s;
    public  int x;
    public int[] rpcarray = new int[4] ;
    public int[] getRpcarray() {
        return rpcarray;
    }
    public void setRpcarray(int[] rpcarray) {
        this.rpcarray = rpcarray;
    }
    public static class rpcpoint{
        public int x;
        public int y;
        public rpcpoint(int x, int y)
        {
            this.x =x;
            this.y =y;
        }

        public rpcpoint() {

        }
    }
    public rpcpoint getPointStruct() {
        return PointStruct;
    }
    public void setPointStruct(rpcpoint pointStruct) {
        PointStruct = pointStruct;
    }
    public rpcpoint PointStruct = new rpcpoint();
    public RpcData() {
    }
    public RpcData (Parcel parcel){
        this.s=parcel.readString();
        this.x=parcel.readInt();
        this.PointStruct.x = parcel.readInt();
        this.PointStruct.y = parcel.readInt();
        // createIntArray() reads the length-prefixed array and allocates the exact
        // size. (The old new int[4] + readIntArray() only worked for 4-element
        // arrays and threw "bad array lengths" for any other size.)
        this.rpcarray = parcel.createIntArray();

    }
    public static final Creator<RpcData> CREATOR = new Creator<RpcData>() {
        @Override
        public RpcData createFromParcel(Parcel out) {
            return new RpcData(out);
        }

        @Override
        public RpcData[] newArray(int size) {
            return new RpcData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(s);
        parcel.writeInt(x);
        parcel.writeInt(PointStruct.x);
        parcel.writeInt(PointStruct.y);
        parcel.writeIntArray(rpcarray);
    }
    public void readFromParcel(Parcel in) {
        s = in.readString();
        x = in.readInt();
        PointStruct.x = in.readInt();
        PointStruct.y = in.readInt();
        rpcarray = in.createIntArray();
    }
    public int getX() {
        return x;
    }
    public void setX(int x) {
        this.x = x;
    }

    public String getS() {
        return s;
    }
    public void setS(String s) {
        this.s = s;
    }

}