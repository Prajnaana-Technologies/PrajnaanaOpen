/*
 * Copyright (c) 2026 Prajnaana Technologies
 * SPDX-License-Identifier: MIT
 *
 * Part of the Multi-Core RPC Framework.
 * See the LICENSE file in the project root for the full license text.
 *
 * Original Author: Mamatha BV
 */
package com.example.aidlserver;
import com.example.aidlserver.RpcData;

interface IRpc {
int socketconnect(String serverIp);
int startServer();          // make THIS device the RPC server/hub (CORE1), then start
int isCorePresent(int coreNum);   // 1 if CORE<coreNum> (1..3) is reachable, else 0
int add ( int a, int b , out RpcData outrpc );
int rpc_call ();
int rpc_compute_sqr ( int x, out RpcData psqr);
int rpc_get_rpc_version_core2 (out RpcData p_rpc_ver);
int rpc_get_rpc_version_core1 (out RpcData p_rpc_ver);
int rpc_get_rpc_version_core3 (out RpcData p_rpc_ver);
int rpc_compute_mod (int x, int y, out RpcData pmod);
int rpc_print_hello (int iSize, inout RpcData strData);
int rpc_print_point_core1 (in RpcData sP, out RpcData psP);
int rpc_array_core3 (int iSize, inout RpcData ai_Arr);


//RPCFN_CORE3  enumRpcErr  fn_array_core3 (IN RPCARR_SIZE int iSize, IN RPC_TYPE_ARRAY int *ai_Arr);
//RPCFN_CORE3  enumRpcErr  fn_test_all (IN int x, IN RPCARR_SIZE int iSize_str, IN RPC_TYPE_ARRAY char *str, IN sPoint sP, IN RPCARR_SIZE int iSize, IN RPC_TYPE_ARRAY int *ai_arr, OUT sPoint *psOut, IN RPCARR_SIZE int outsize, OUT RPC_TYPE_ARRAY int *ai_out);

}